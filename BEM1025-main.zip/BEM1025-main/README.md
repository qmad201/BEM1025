# BEM1025
Programming for Business Analytics
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/mosleh-exeter/BEM1025/HEAD)
